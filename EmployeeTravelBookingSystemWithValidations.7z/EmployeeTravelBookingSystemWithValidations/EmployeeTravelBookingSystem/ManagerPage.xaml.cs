﻿using EmployeeTravelBookingSystem.BussinessLayer;
using EmployeeTravelBookingSystem.Exception;
using Entity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Window
    {
        private string managerUser;
        private string password;
        public int managerid;

        public ManagerPage()
        {
            InitializeComponent();
        }

        public ManagerPage(string managerUser, string password)
        {
            this.managerUser = managerUser;
            this.password = password;
            InitializeComponent();
        }

        private void BtnManagerDisplay_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int mid = managerid;
                TravelRequest display = new TravelRequest();
                BookingBL requestDisplay = new BookingBL();
                DataTable dt = requestDisplay.DisplayManagerRequestBL(mid);
                if (dt != null)
                {
                    dataGridManager.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("No requests are made by Employees");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void ManagerGrid_Loaded(object sender, RoutedEventArgs e)
        {

            try
            {
                string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "mini.GetManagers";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", managerUser);
                cmd.Parameters.AddWithValue("@password", password);


                SqlParameter Managerid = new SqlParameter("@managerid", SqlDbType.Int) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(Managerid);
                SqlParameter manName = new SqlParameter("@Managername", SqlDbType.VarChar, 20) { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(manName);

                con.Open();
                SqlDataReader sd = cmd.ExecuteReader();
                managerUser = manName.Value.ToString();
                managerid = int.Parse(Managerid.Value.ToString());
                con.Close();
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
         




        }

        private void BtnManagerApproved_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                int requestId = int.Parse(txtEmpRequestID.Text);
                TravelRequest approve = new TravelRequest();
                BookingBL updateRequest = new BookingBL();
                bool updated = updateRequest.ApproveRequestBL(requestId);
                if (updated)
                {

                    MessageBox.Show("Approved");
                    txtEmpRequestID.Text = " ";
                }
                else
                {
                    MessageBox.Show("Can't Approve");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnManagerCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int requestId = int.Parse(txtEmpRequestID.Text);
                TravelRequest approve = new TravelRequest();
                BookingBL updateRequest = new BookingBL();
                bool updated = updateRequest.RejectRequestBL(requestId);
                if (updated)
                {
                    MessageBox.Show("Rejected");
                    txtEmpRequestID.Text = " ";
                }
                else
                {
                    MessageBox.Show("Request not Found");
                }
            }
            catch (EmployeeTravelBookingException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnmanagerLogOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
