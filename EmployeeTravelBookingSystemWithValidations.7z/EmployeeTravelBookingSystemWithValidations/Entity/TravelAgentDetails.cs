﻿namespace Entity
{
    public class TravelAgentDetails
    {
        public string agentName { get; set; }
        public string agentUsername { get; set; }
        public string agentPassword { get; set; }

    }
}